import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'

const fmt = (n) => {
  if (n === null || n === undefined || isNaN(n)) return '— DA'
  return Math.round(n).toLocaleString('ar-DZ') + ' DA'
}
const fmtN = (n) => Math.round(n || 0).toLocaleString('ar-DZ')
const today = () => new Date().toISOString().slice(0, 10)

const P_COLORS = ['#3B82F6','#10B981','#F59E0B','#EF4444','#8B5CF6','#EC4899','#06B6D4','#84CC16','#F97316','#6366F1']

export default function Home() {
  const [tab, setTab] = useState('home')
  const [products, setProducts] = useState([])
  const [entries, setEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState(null)

  // Modals
  const [showProductModal, setShowProductModal] = useState(false)
  const [showDailyModal, setShowDailyModal] = useState(false)
  const [editProduct, setEditProduct] = useState(null)
  const [editEntry, setEditEntry] = useState(null)

  // Product form
  const [pForm, setPForm] = useState({ name:'', purchase:0, sell:0, packaging:50, ads:0, color:'#3B82F6' })

  // Daily form
  const [dForm, setDForm] = useState({ date: today(), sharedAds:0, sharedCosts:0, items:{} })

  const showToast = (msg, err=false) => {
    setToast({ msg, err })
    setTimeout(() => setToast(null), 2500)
  }

  // ── Load data ──
  const loadData = useCallback(async () => {
    setLoading(true)
    const [{ data: prods }, { data: ents }] = await Promise.all([
      supabase.from('products').select('*').order('created_at'),
      supabase.from('daily_entries').select('*, entry_products(*)').order('date', { ascending: false })
    ])
    setProducts(prods || [])
    setEntries(ents || [])
    setLoading(false)
  }, [])

  useEffect(() => { loadData() }, [loadData])

  // ── Calculations ──
  const calcEntry = (entry) => {
    let revenue = 0, costs = 0, sales = 0, rets = 0
    for (const ep of (entry.entry_products || [])) {
      const p = products.find(x => x.id === ep.product_id)
      if (!p) continue
      const net = ep.gross_sales - ep.returns
      revenue += net * p.sell_price
      costs += net * (p.purchase_price + p.packaging) + ep.ads
      sales += ep.gross_sales
      rets += ep.returns
    }
    costs += (entry.shared_ads || 0) + (entry.shared_costs || 0)
    return { revenue, costs, profit: revenue - costs, sales, rets }
  }

  const calcProduct = (pid) => {
    let revenue = 0, costs = 0, sales = 0, rets = 0
    for (const e of entries) {
      const ep = (e.entry_products || []).find(x => x.product_id === pid)
      if (!ep) continue
      const p = products.find(x => x.id === pid)
      if (!p) continue
      const net = ep.gross_sales - ep.returns
      revenue += net * p.sell_price
      costs += net * (p.purchase_price + p.packaging) + ep.ads
      sales += ep.gross_sales
      rets += ep.returns
    }
    return { revenue, costs, profit: revenue - costs, sales, rets }
  }

  const getMonthEntries = () => {
    const now = new Date()
    return entries.filter(e => {
      const d = new Date(e.date)
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth()
    })
  }

  const getWeekEntries = () => {
    const now = new Date()
    const day = now.getDay()
    const monday = new Date(now)
    monday.setDate(now.getDate() - ((day + 6) % 7))
    monday.setHours(0, 0, 0, 0)
    return entries.filter(e => new Date(e.date) >= monday)
  }

  // ── Product CRUD ──
  const openProductModal = (p = null) => {
    if (p) {
      setEditProduct(p)
      setPForm({ name: p.name, purchase: p.purchase_price, sell: p.sell_price, packaging: p.packaging, ads: p.ads_default, color: p.color })
    } else {
      setEditProduct(null)
      setPForm({ name:'', purchase:0, sell:0, packaging:50, ads:0, color:'#3B82F6' })
    }
    setShowProductModal(true)
  }

  const saveProduct = async () => {
    if (!pForm.name.trim()) { showToast('أدخل اسم المنتج', true); return }
    if (!pForm.sell) { showToast('أدخل سعر البيع', true); return }
    const data = { name: pForm.name.trim(), purchase_price: +pForm.purchase||0, sell_price: +pForm.sell||0, packaging: +pForm.packaging||0, ads_default: +pForm.ads||0, color: pForm.color }
    if (editProduct) {
      await supabase.from('products').update(data).eq('id', editProduct.id)
      showToast('✅ تم تعديل المنتج')
    } else {
      await supabase.from('products').insert(data)
      showToast('✅ تم إضافة المنتج')
    }
    setShowProductModal(false)
    loadData()
  }

  const deleteProduct = async (id) => {
    if (!confirm('حذف هذا المنتج؟')) return
    await supabase.from('products').delete().eq('id', id)
    showToast('🗑️ تم الحذف')
    loadData()
  }

  // ── Daily CRUD ──
  const openDailyModal = (entry = null) => {
    if (!products.length) { showToast('أضف منتجاً أولاً', true); return }
    if (entry) {
      setEditEntry(entry)
      const items = {}
      for (const ep of (entry.entry_products || [])) {
        items[ep.product_id] = { gross: ep.gross_sales, returns: ep.returns, ads: ep.ads }
      }
      setDForm({ date: entry.date, sharedAds: entry.shared_ads, sharedCosts: entry.shared_costs, items })
    } else {
      setEditEntry(null)
      setDForm({ date: today(), sharedAds: 0, sharedCosts: 0, items: {} })
    }
    setShowDailyModal(true)
  }

  const saveDailyEntry = async () => {
    const { date, sharedAds, sharedCosts, items } = dForm
    if (!date) { showToast('اختر التاريخ', true); return }

    let entryId
    if (editEntry) {
      await supabase.from('daily_entries').update({ date, shared_ads: +sharedAds||0, shared_costs: +sharedCosts||0 }).eq('id', editEntry.id)
      await supabase.from('entry_products').delete().eq('entry_id', editEntry.id)
      entryId = editEntry.id
    } else {
      // delete existing entry for same date
      const existing = entries.find(e => e.date === date)
      if (existing) {
        await supabase.from('daily_entries').delete().eq('id', existing.id)
      }
      const { data } = await supabase.from('daily_entries').insert({ date, shared_ads: +sharedAds||0, shared_costs: +sharedCosts||0 }).select().single()
      entryId = data.id
    }

    const eps = products.map(p => ({
      entry_id: entryId,
      product_id: p.id,
      gross_sales: +(items[p.id]?.gross || 0),
      returns: +(items[p.id]?.returns || 0),
      ads: +(items[p.id]?.ads ?? p.ads_default ?? 0),
    }))
    await supabase.from('entry_products').insert(eps)
    setShowDailyModal(false)
    showToast('✅ تم حفظ اليوم')
    loadData()
  }

  const deleteEntry = async (id) => {
    if (!confirm('حذف هذا اليوم؟')) return
    await supabase.from('daily_entries').delete().eq('id', id)
    showToast('🗑️ تم الحذف')
    loadData()
  }

  // ── Preview calc ──
  const dailyPreview = () => {
    let rev = 0, cost = 0, sales = 0
    for (const p of products) {
      const gross = +(dForm.items[p.id]?.gross || 0)
      const rets = +(dForm.items[p.id]?.returns || 0)
      const ads = +(dForm.items[p.id]?.ads ?? p.ads_default ?? 0)
      const net = gross - rets
      rev += net * p.sell_price
      cost += net * (p.purchase_price + p.packaging) + ads
      sales += gross
    }
    cost += +(dForm.sharedAds || 0) + +(dForm.sharedCosts || 0)
    return { rev, cost, profit: rev - cost, sales }
  }

  // ── Render ──
  if (loading) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100dvh', flexDirection:'column', gap:16 }}>
      <div style={{ width:40, height:40, border:'3px solid #1E2D45', borderTopColor:'#3B82F6', borderRadius:'50%', animation:'spin 1s linear infinite' }}></div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ color:'#64748B', fontSize:14 }}>جاري التحميل...</div>
    </div>
  )

  const todayEntry = entries.find(e => e.date === today())
  const todayCalc = todayEntry ? calcEntry(todayEntry) : null
  const mEntries = getMonthEntries()
  const wEntries = getWeekEntries()
  let mProfit = 0, mSales = 0
  mEntries.forEach(e => { const c = calcEntry(e); mProfit += c.profit; mSales += c.sales })
  let wRev = 0, wCost = 0, wPro = 0, wSales = 0
  wEntries.forEach(e => { const c = calcEntry(e); wRev += c.revenue; wCost += c.costs; wPro += c.profit; wSales += c.sales })
  let allRev = 0, allCost = 0, allPro = 0, allSales = 0, allRets = 0
  mEntries.forEach(e => { const c = calcEntry(e); allRev += c.revenue; allCost += c.costs; allPro += c.profit; allSales += c.sales; allRets += c.rets })

  const S = {
    app: { display:'flex', flexDirection:'column', minHeight:'100dvh', maxWidth:480, margin:'0 auto', position:'relative' },
    hdr: { padding:'14px 18px 10px', background:'#111827', borderBottom:'1px solid #1E2D45', flexShrink:0, position:'sticky', top:0, zIndex:50 },
    h1: { fontSize:18, fontWeight:900, letterSpacing:'-0.5px' },
    accent: { color:'#3B82F6' },
    sub: { fontSize:11, color:'#64748B', marginTop:2 },
    content: { flex:1, overflowY:'auto', padding:'14px 14px 80px' },
    tabs: { position:'fixed', bottom:0, left:'50%', transform:'translateX(-50%)', width:'100%', maxWidth:480, height:60, background:'#111827', borderTop:'1px solid #1E2D45', display:'flex', zIndex:100 },
    tab: (active) => ({ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:3, fontSize:10, color: active?'#3B82F6':'#64748B', cursor:'pointer', background:'none', border:'none', fontFamily:"'Cairo', sans-serif", transition:'color .2s' }),
    card: { background:'#1A2235', border:'1px solid #1E2D45', borderRadius:14, padding:14, marginBottom:12 },
    cardTitle: { fontSize:13, fontWeight:700, color:'#64748B', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:12, display:'flex', alignItems:'center', gap:6 },
    dot: (c='#3B82F6') => ({ width:7, height:7, borderRadius:'50%', background:c, flexShrink:0 }),
    kpiGrid: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:12 },
    kpi: { background:'#1A2235', border:'1px solid #1E2D45', borderRadius:14, padding:'14px 12px' },
    kpiLabel: { fontSize:10, color:'#64748B', marginBottom:6, fontFamily:"'Cairo',sans-serif" },
    kpiVal: (c='#3B82F6') => ({ fontSize:20, fontWeight:900, lineHeight:1, color:c }),
    field: { marginBottom:12 },
    label: { display:'block', fontSize:11, color:'#64748B', marginBottom:5 },
    input: { width:'100%', background:'#0F1929', border:'1px solid #1E2D45', borderRadius:10, padding:'11px 13px', color:'#F1F5F9', fontSize:15, fontFamily:"'Cairo',sans-serif", outline:'none' },
    btn: (bg='#3B82F6', full=true) => ({ width: full?'100%':'auto', padding: full?'13px':'8px 16px', borderRadius:14, border:'none', fontSize: full?15:12, fontWeight:700, fontFamily:"'Cairo',sans-serif", cursor:'pointer', background:bg, color:'#fff', transition:'opacity .15s' }),
    row: { display:'flex', justifyContent:'space-between', padding:'10px 0', borderBottom:'1px solid #1E2D45', fontSize:13 },
    lbl: { color:'#64748B' },
    val: (c='#F1F5F9') => ({ fontWeight:700, color:c }),
    overlay: (open) => ({ position:'fixed', inset:0, background:'rgba(0,0,0,.7)', zIndex:200, display:'flex', alignItems:'flex-end', opacity: open?1:0, pointerEvents: open?'all':'none', transition:'opacity .25s' }),
    modal: (open) => ({ background:'#111827', borderRadius:'20px 20px 0 0', padding:'20px 18px 40px', width:'100%', maxHeight:'90dvh', overflowY:'auto', transform: open?'translateY(0)':'translateY(100%)', transition:'transform .3s cubic-bezier(.4,0,.2,1)' }),
    handle: { width:40, height:4, background:'#1E2D45', borderRadius:2, margin:'0 auto 16px' },
    modalTitle: { fontSize:17, fontWeight:900, marginBottom:18 },
    badge: (pos) => ({ display:'inline-block', padding:'2px 8px', borderRadius:20, fontSize:10, fontWeight:700, background: pos?'rgba(16,185,129,.15)':'rgba(239,68,68,.15)', color: pos?'#10B981':'#EF4444' }),
    sectionLabel: { fontSize:11, fontWeight:700, color:'#64748B', letterSpacing:1, textTransform:'uppercase', margin:'16px 0 10px' },
    empty: { textAlign:'center', padding:'40px 20px', color:'#64748B' },
  }

  const pv = dailyPreview()

  return (
    <div style={S.app}>
      {/* Header */}
      <div style={S.hdr}>
        <h1 style={S.h1}>🛒 <span style={S.accent}>Ta7tadjhaa</span> — محاسبة</h1>
        <div style={S.sub}>{new Date().toLocaleDateString('ar-DZ',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
      </div>

      {/* Content */}
      <div style={S.content}>

        {/* ══ HOME ══ */}
        {tab === 'home' && (
          <>
            <div style={S.kpiGrid}>
              <div style={S.kpi}><div style={S.kpiLabel}>إيراد اليوم</div><div style={S.kpiVal('#3B82F6')}>{todayCalc ? fmt(todayCalc.revenue) : '—'}</div></div>
              <div style={S.kpi}><div style={S.kpiLabel}>ربح اليوم</div><div style={S.kpiVal(todayCalc ? (todayCalc.profit>=0?'#10B981':'#EF4444') : '#64748B')}>{todayCalc ? fmt(todayCalc.profit) : '—'}</div></div>
              <div style={S.kpi}><div style={S.kpiLabel}>مبيعات اليوم</div><div style={S.kpiVal('#F59E0B')}>{todayCalc ? fmtN(todayCalc.sales) : '—'}</div></div>
              <div style={S.kpi}><div style={S.kpiLabel}>ربح الشهر</div><div style={S.kpiVal(mProfit>=0?'#10B981':'#EF4444')}>{fmt(mProfit)}</div></div>
            </div>

            <div style={S.card}>
              <div style={S.cardTitle}><div style={S.dot('#10B981')}></div>ملخص الشهر</div>
              <div style={S.row}><span style={S.lbl}>إجمالي المبيعات</span><span style={S.val()}>{fmtN(allSales)}</span></div>
              <div style={S.row}><span style={S.lbl}>إيراد صافي</span><span style={S.val('#10B981')}>{fmt(allRev)}</span></div>
              <div style={S.row}><span style={S.lbl}>إجمالي التكاليف</span><span style={S.val('#EF4444')}>{fmt(allCost)}</span></div>
              <div style={{ ...S.row, borderBottom:'none', paddingTop:14 }}><span style={{ fontWeight:700 }}>صافي الربح</span><span style={S.val(allPro>=0?'#10B981':'#EF4444')}>{fmt(allPro)}</span></div>
            </div>

            <div style={S.sectionLabel}>آخر الأيام</div>
            {entries.slice(0,5).map(e => {
              const c = calcEntry(e)
              const d = new Date(e.date)
              return (
                <div key={e.id} style={{ ...S.card, borderRight:`3px solid ${c.profit>=0?'#10B981':'#EF4444'}` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                    <div style={{ fontSize:13, fontWeight:700 }}>{d.toLocaleDateString('ar-DZ',{weekday:'short',day:'numeric',month:'short'})}</div>
                    <div style={{ fontSize:16, fontWeight:900, color: c.profit>=0?'#10B981':'#EF4444' }}>{fmt(c.profit)}</div>
                  </div>
                  <div style={{ fontSize:11, color:'#64748B' }}>إيراد: {fmt(c.revenue)} | تكاليف: {fmt(c.costs)} | مبيعات: {fmtN(c.sales)}</div>
                </div>
              )
            })}
            {!entries.length && <div style={S.empty}><div style={{fontSize:36,marginBottom:8}}>📋</div><div style={{fontSize:13}}>لا توجد إدخالات بعد</div></div>}

            <button style={S.btn('#3B82F6')} onClick={() => openDailyModal()}>➕ تسجيل مبيعات اليوم</button>
          </>
        )}

        {/* ══ PRODUCTS ══ */}
        {tab === 'products' && (
          <>
            {!products.length && <div style={S.empty}><div style={{fontSize:36,marginBottom:8}}>📦</div><div style={{fontSize:13}}>لا توجد منتجات<br/>أضف منتجك الأول</div></div>}
            {products.map(p => {
              const margin = p.sell_price - p.purchase_price - p.packaging
              const pct = p.sell_price > 0 ? (margin/p.sell_price*100) : 0
              return (
                <div key={p.id} style={{ ...S.card, borderRight:`3px solid ${p.color}`, marginBottom:8 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                    <div style={{ flex:1 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                        <div style={{ width:10, height:10, borderRadius:'50%', background:p.color, flexShrink:0 }}></div>
                        <div style={{ fontSize:15, fontWeight:700 }}>{p.name}</div>
                      </div>
                      <div style={{ fontSize:11, color:'#64748B', lineHeight:1.8 }}>
                        شراء: {fmt(p.purchase_price)} | بيع: {fmt(p.sell_price)}<br/>
                        تغليف: {fmt(p.packaging)} | Ads: {fmt(p.ads_default)}/يوم
                      </div>
                    </div>
                    <div style={{ textAlign:'center', marginRight:8 }}>
                      <div style={{ fontSize:18, fontWeight:900, color: margin>=0?'#10B981':'#EF4444' }}>{fmt(margin)}</div>
                      <div style={{ fontSize:10, color:'#64748B' }}>هامش/وحدة</div>
                      <span style={S.badge(margin>=0)}>{pct.toFixed(0)}%</span>
                    </div>
                  </div>
                  <div style={{ display:'flex', gap:8, marginTop:10 }}>
                    <button style={S.btn('#1E2D45', false)} onClick={() => openProductModal(p)}>✏️ تعديل</button>
                    <button style={S.btn('#7F1D1D', false)} onClick={() => deleteProduct(p.id)}>🗑️ حذف</button>
                  </div>
                </div>
              )
            })}
            <button style={{...S.btn('#3B82F6'), marginTop:10}} onClick={() => openProductModal()}>➕ إضافة منتج</button>
          </>
        )}

        {/* ══ LOG ══ */}
        {tab === 'log' && (
          <>
            {!entries.length && <div style={S.empty}><div style={{fontSize:36,marginBottom:8}}>📅</div><div style={{fontSize:13}}>لا توجد إدخالات يومية</div></div>}
            {entries.map(e => {
              const c = calcEntry(e)
              const d = new Date(e.date)
              return (
                <div key={e.id} style={{ ...S.card, borderRight:`3px solid ${c.profit>=0?'#10B981':'#EF4444'}` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                    <div style={{ fontSize:13, fontWeight:700 }}>{d.toLocaleDateString('ar-DZ',{weekday:'long',day:'numeric',month:'long'})}</div>
                    <div style={{ fontSize:16, fontWeight:900, color: c.profit>=0?'#10B981':'#EF4444' }}>{fmt(c.profit)}</div>
                  </div>
                  <div style={{ fontSize:11, color:'#64748B', marginBottom:10 }}>إيراد: {fmt(c.revenue)} | تكاليف: {fmt(c.costs)}</div>
                  {(e.entry_products||[]).filter(ep=>ep.gross_sales>0||ep.returns>0).map(ep => {
                    const p = products.find(x=>x.id===ep.product_id)
                    if (!p) return null
                    const net = ep.gross_sales - ep.returns
                    const pRev = net * p.sell_price
                    const pCost = net * (p.purchase_price + p.packaging) + ep.ads
                    const pPro = pRev - pCost
                    return (
                      <div key={ep.id} style={{ display:'flex', justifyContent:'space-between', fontSize:12, padding:'4px 0', borderBottom:'1px solid #1E2D45' }}>
                        <span style={{ color:p.color, fontWeight:600 }}>{p.name}</span>
                        <span>{fmtN(ep.gross_sales)}{ep.returns>0?` (-${ep.returns})`:''} | <span style={{ color: pPro>=0?'#10B981':'#EF4444' }}>{fmt(pPro)}</span></span>
                      </div>
                    )
                  })}
                  <div style={{ display:'flex', gap:8, marginTop:10 }}>
                    <button style={S.btn('#1E2D45', false)} onClick={() => openDailyModal(e)}>✏️ تعديل</button>
                    <button style={S.btn('#7F1D1D', false)} onClick={() => deleteEntry(e.id)}>🗑️ حذف</button>
                  </div>
                </div>
              )
            })}
            <button style={{...S.btn('#3B82F6'), marginTop:10}} onClick={() => openDailyModal()}>➕ تسجيل يوم جديد</button>
          </>
        )}

        {/* ══ SUMMARY ══ */}
        {tab === 'summary' && (
          <>
            <div style={S.sectionLabel}>📅 هذا الأسبوع ({wEntries.length} أيام)</div>
            <div style={S.card}>
              <div style={S.row}><span style={S.lbl}>مبيعات</span><span style={S.val()}>{fmtN(wSales)}</span></div>
              <div style={S.row}><span style={S.lbl}>إيراد</span><span style={S.val('#10B981')}>{fmt(wRev)}</span></div>
              <div style={S.row}><span style={S.lbl}>تكاليف</span><span style={S.val('#EF4444')}>{fmt(wCost)}</span></div>
              <div style={{ ...S.row, borderBottom:'none', paddingTop:14 }}><span style={{ fontWeight:700, fontSize:15 }}>صافي الربح</span><span style={{ fontWeight:900, fontSize:18, color: wPro>=0?'#10B981':'#EF4444' }}>{fmt(wPro)}</span></div>
            </div>

            <div style={S.sectionLabel}>📈 هذا الشهر ({mEntries.length} أيام)</div>
            <div style={S.card}>
              <div style={S.row}><span style={S.lbl}>مبيعات إجمالية</span><span style={S.val()}>{fmtN(allSales)}</span></div>
              <div style={S.row}><span style={S.lbl}>مرتجعات (روتور)</span><span style={S.val('#EF4444')}>{fmtN(allRets)}</span></div>
              <div style={S.row}><span style={S.lbl}>إيراد صافي</span><span style={S.val('#10B981')}>{fmt(allRev)}</span></div>
              <div style={S.row}><span style={S.lbl}>إجمالي التكاليف</span><span style={S.val('#EF4444')}>{fmt(allCost)}</span></div>
              <div style={S.row}><span style={S.lbl}>هامش %</span><span style={S.val()}>{allRev>0?(allPro/allRev*100).toFixed(1):0}%</span></div>
              <div style={{ ...S.row, borderBottom:'none', paddingTop:14 }}><span style={{ fontWeight:700, fontSize:15 }}>صافي الربح</span><span style={{ fontWeight:900, fontSize:18, color: allPro>=0?'#10B981':'#EF4444' }}>{fmt(allPro)}</span></div>
            </div>

            <div style={S.sectionLabel}>🏆 أداء المنتجات</div>
            {products.map(p => {
              const c = calcProduct(p.id)
              const m = c.revenue>0?(c.profit/c.revenue*100):0
              return (
                <div key={p.id} style={{ ...S.card, borderRight:`3px solid ${p.color}` }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <div style={{ width:10, height:10, borderRadius:'50%', background:p.color }}></div>
                      <div style={{ fontSize:14, fontWeight:700 }}>{p.name}</div>
                    </div>
                    <span style={S.badge(c.profit>=0)}>{m.toFixed(0)}%</span>
                  </div>
                  <div style={S.row}><span style={S.lbl}>مبيعات</span><span style={S.val()}>{fmtN(c.sales)}</span></div>
                  <div style={S.row}><span style={S.lbl}>مرتجعات</span><span style={S.val('#EF4444')}>{fmtN(c.rets)}</span></div>
                  <div style={S.row}><span style={S.lbl}>إيراد</span><span style={S.val()}>{fmt(c.revenue)}</span></div>
                  <div style={{ ...S.row, borderBottom:'none' }}><span style={{ fontWeight:700 }}>الربح</span><span style={S.val(c.profit>=0?'#10B981':'#EF4444')}>{fmt(c.profit)}</span></div>
                </div>
              )
            })}
          </>
        )}
      </div>

      {/* ══ TABS ══ */}
      <div style={S.tabs}>
        {[
          { id:'home', icon:'🏠', label:'الرئيسية' },
          { id:'products', icon:'📦', label:'المنتجات' },
          { id:'log', icon:'📅', label:'السجل' },
          { id:'summary', icon:'📈', label:'الحصائل' },
        ].map(t => (
          <button key={t.id} style={S.tab(tab===t.id)} onClick={() => setTab(t.id)}>
            <span style={{ fontSize:22 }}>{t.icon}</span>
            {t.label}
          </button>
        ))}
      </div>

      {/* ══ MODAL: Product ══ */}
      <div style={S.overlay(showProductModal)} onClick={e => e.target===e.currentTarget&&setShowProductModal(false)}>
        <div style={S.modal(showProductModal)}>
          <div style={S.handle}></div>
          <div style={S.modalTitle}>{editProduct ? '✏️ تعديل المنتج' : '➕ منتج جديد'}</div>
          <div style={S.field}><label style={S.label}>اسم المنتج *</label><input style={S.input} value={pForm.name} onChange={e=>setPForm({...pForm,name:e.target.value})} placeholder="مثال: ثوب رجالي أزرق" /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <div style={S.field}><label style={S.label}>سعر الشراء (DA)</label><input type="number" style={S.input} value={pForm.purchase} onChange={e=>setPForm({...pForm,purchase:e.target.value})} /></div>
            <div style={S.field}><label style={S.label}>سعر البيع (DA) *</label><input type="number" style={S.input} value={pForm.sell} onChange={e=>setPForm({...pForm,sell:e.target.value})} /></div>
            <div style={S.field}><label style={S.label}>تغليف (DA)</label><input type="number" style={S.input} value={pForm.packaging} onChange={e=>setPForm({...pForm,packaging:e.target.value})} /></div>
            <div style={S.field}><label style={S.label}>Ads/يوم (DA)</label><input type="number" style={S.input} value={pForm.ads} onChange={e=>setPForm({...pForm,ads:e.target.value})} /></div>
          </div>
          <div style={S.field}>
            <label style={S.label}>اللون</label>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {P_COLORS.map(c => (
                <div key={c} onClick={()=>setPForm({...pForm,color:c})} style={{ width:30, height:30, borderRadius:'50%', background:c, cursor:'pointer', border: pForm.color===c?'3px solid #fff':'3px solid transparent', transition:'border .15s' }}></div>
              ))}
            </div>
          </div>
          {pForm.sell>0 && (
            <div style={{ ...S.card, marginBottom:14 }}>
              <div style={{ fontSize:12, color:'#64748B', marginBottom:8 }}>معاينة الهامش</div>
              <div style={S.row}><span style={S.lbl}>تكاليف/وحدة</span><span style={S.val()}>{fmt((+pForm.purchase||0)+(+pForm.packaging||0))}</span></div>
              <div style={{ ...S.row, borderBottom:'none' }}><span style={{ fontWeight:700 }}>هامش/وحدة</span><span style={{ fontWeight:900, color: ((+pForm.sell||0)-(+pForm.purchase||0)-(+pForm.packaging||0))>=0?'#10B981':'#EF4444' }}>{fmt((+pForm.sell||0)-(+pForm.purchase||0)-(+pForm.packaging||0))}</span></div>
            </div>
          )}
          <div style={{ display:'flex', gap:10 }}>
            <button style={S.btn('#10B981')} onClick={saveProduct}>💾 حفظ</button>
            <button style={{ ...S.btn('#1E2D45', false), padding:'13px 20px' }} onClick={()=>setShowProductModal(false)}>إلغاء</button>
          </div>
        </div>
      </div>

      {/* ══ MODAL: Daily ══ */}
      <div style={S.overlay(showDailyModal)} onClick={e => e.target===e.currentTarget&&setShowDailyModal(false)}>
        <div style={S.modal(showDailyModal)}>
          <div style={S.handle}></div>
          <div style={S.modalTitle}>📅 تسجيل مبيعات</div>
          <div style={S.field}><label style={S.label}>التاريخ</label><input type="date" style={S.input} value={dForm.date} onChange={e=>setDForm({...dForm,date:e.target.value})} /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <div style={S.field}><label style={S.label}>Ads مشتركة (DA)</label><input type="number" style={S.input} value={dForm.sharedAds} onChange={e=>setDForm({...dForm,sharedAds:e.target.value})} /></div>
            <div style={S.field}><label style={S.label}>مصاريف مشتركة (DA)</label><input type="number" style={S.input} value={dForm.sharedCosts} onChange={e=>setDForm({...dForm,sharedCosts:e.target.value})} /></div>
          </div>
          <div style={{ height:1, background:'#1E2D45', margin:'4px 0 14px' }}></div>
          {products.map(p => (
            <div key={p.id} style={{ ...S.card, borderRight:`3px solid ${p.color}`, marginBottom:10 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10 }}>
                <div style={{ width:8, height:8, borderRadius:'50%', background:p.color }}></div>
                <div style={{ fontSize:14, fontWeight:700 }}>{p.name}</div>
                <div style={{ fontSize:11, color:'#64748B', marginRight:'auto' }}>بيع: {fmt(p.sell_price)}</div>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8 }}>
                <div><div style={{ fontSize:10, color:'#64748B', marginBottom:4 }}>مبيعات</div><input type="number" style={{ ...S.input, fontSize:16, textAlign:'center', padding:'8px' }} value={dForm.items[p.id]?.gross||''} placeholder="0" onChange={e=>setDForm({...dForm,items:{...dForm.items,[p.id]:{...dForm.items[p.id],gross:e.target.value}}})} /></div>
                <div><div style={{ fontSize:10, color:'#64748B', marginBottom:4 }}>روتور</div><input type="number" style={{ ...S.input, fontSize:16, textAlign:'center', padding:'8px' }} value={dForm.items[p.id]?.returns||''} placeholder="0" onChange={e=>setDForm({...dForm,items:{...dForm.items,[p.id]:{...dForm.items[p.id],returns:e.target.value}}})} /></div>
                <div><div style={{ fontSize:10, color:'#64748B', marginBottom:4 }}>Ads</div><input type="number" style={{ ...S.input, fontSize:16, textAlign:'center', padding:'8px' }} value={dForm.items[p.id]?.ads??''} placeholder={p.ads_default} onChange={e=>setDForm({...dForm,items:{...dForm.items,[p.id]:{...dForm.items[p.id],ads:e.target.value}}})} /></div>
              </div>
            </div>
          ))}
          {pv.sales > 0 && (
            <div style={{ ...S.card, marginBottom:14 }}>
              <div style={{ fontSize:12, color:'#64748B', marginBottom:8 }}>معاينة اليوم</div>
              <div style={S.row}><span style={S.lbl}>مبيعات</span><span style={S.val()}>{fmtN(pv.sales)}</span></div>
              <div style={S.row}><span style={S.lbl}>إيراد</span><span style={S.val('#10B981')}>{fmt(pv.rev)}</span></div>
              <div style={S.row}><span style={S.lbl}>تكاليف</span><span style={S.val('#EF4444')}>{fmt(pv.cost)}</span></div>
              <div style={{ ...S.row, borderBottom:'none', paddingTop:12 }}><span style={{ fontWeight:700 }}>صافي الربح</span><span style={{ fontWeight:900, fontSize:18, color: pv.profit>=0?'#10B981':'#EF4444' }}>{fmt(pv.profit)}</span></div>
            </div>
          )}
          <div style={{ display:'flex', gap:10 }}>
            <button style={S.btn('#10B981')} onClick={saveDailyEntry}>💾 حفظ اليوم</button>
            <button style={{ ...S.btn('#1E2D45', false), padding:'13px 20px' }} onClick={()=>setShowDailyModal(false)}>إلغاء</button>
          </div>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div style={{ position:'fixed', top:20, left:'50%', transform:'translateX(-50%)', background: toast.err?'#EF4444':'#10B981', color:'#fff', padding:'10px 20px', borderRadius:30, fontSize:13, fontWeight:700, zIndex:999, whiteSpace:'nowrap' }}>
          {toast.msg}
        </div>
      )}
    </div>
  )
}
